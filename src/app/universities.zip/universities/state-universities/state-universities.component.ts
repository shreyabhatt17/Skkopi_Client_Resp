import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params, ParamMap } from '@angular/router';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/observable/of';


//import { Subscription } from 'rxjs/Subscription';

import { StateUniversitiesList } from '../../shared/_models/stateUniList.model';

import { UniversitiesService } from '../../services/universities.service';

@Component({
  selector: 'app-state-universities',
  templateUrl: './state-universities.component.html',
  styleUrls: ['./state-universities.component.scss']
})
export class StateUniversitiesComponent implements OnInit, OnDestroy{

  //stateUniversities: {id: number, name: string};

  //stateUniversitiesData = {};

  user: { id: number, name: string};

  unidata: {state: string, name: string, city: string};


  title='universities';

  // state: any;

 stateUniversitiesData: any;
 stateUniveristyData: any;
 stateuniversityArray = [];
 universitiesData = {};
 //unidata: any;

  constructor( private route: ActivatedRoute, private universitiesService: UniversitiesService, private router: Router) { }

  // ngOnInit() {

  //   this.getStateUniversities(); 
  // }
          //this.stateUniversity = Array.of(this.stateUniversity); 


  ngOnInit(): void {

    // var _this = this;  

    // this.route.paramMap
    //   .switchMap((params: ParamMap) => this.universitiesService.getUniversity(params.get('state')))
    //   .subscribe(stateUniversitiesData => {
    //     this.stateUniversitiesData = stateUniversitiesData;
    //     console.log(this.stateUniversitiesData, 'state university data');
    //     }
        
    //   ); 

    this.route.params.subscribe((params:Params) => {
      this.stateUniversitiesData = params['state']
    })

    console.log(this.stateUniversitiesData);

      // this.getStateUniversities(); 
     } 

  // onLoadUser(id: number){
  //      this.router.navigate(['/state-universities', id, 'Chris'], {queryParams: {allowUser: '3'}, fragment:"loading"});
  //   }


  ngOnDestroy(){

  }

    getStateUniversities(){
    this.universitiesService.getUniversityRequest().subscribe(
      stateUniversitiesData => {
          this.stateUniversitiesData = stateUniversitiesData;
          console.log(this.stateUniversitiesData ,'unicount');       
          this.stateUniveristyData = this.stateUniversitiesData.data.universities;
          console.log(this.stateUniveristyData , 'state  universities data');

             
      },
      (error) => console.log(error)
    );
  }

   viewMainData(state){
    this.router.navigate(['/main-university', state]);
  } 



}
