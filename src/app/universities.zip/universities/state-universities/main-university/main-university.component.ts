import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
// import { Observable } from 'rxjs';
// import { of } from 'rxjs/Observable/of';
// import 'rxjs/add/operator/map';
// import 'rxjs/add/operator/switchMap';
// import 'rxjs/add/observable/of';
//import 'rxjs';

import { MainUniversity } from '../../../shared/_models/mainUniversity.model';
import { CategoryLinkLists } from '../../../shared/_models/categoryLists.model';

import { UniversitiesService } from '../../../services/universities.service';


@Component({
  selector: 'app-main-university',
  templateUrl: './main-university.component.html',
  styleUrls: ['./main-university.component.scss']
})
export class MainUniversityComponent implements OnInit {

  user: { id: number, name: string, status: string };

  universitiesData: any;
  universityData: any;
  mainUniversityData: any;
  name: any;
  state: any;

  stateUniversityArray = [];

   _id:any;


  constructor( private universitiesService:UniversitiesService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {

    this.getUniversityData();

    // this.user = {
    //   id: this.route.snapshot.params['id'],
    //   name: this.route.snapshot.params['name'],
    //   status: this.route.snapshot.params['status']
    // };

    // this.route.params
    // .subscribe(
    //  (params: Params) => {
    //   this.user.id = params['id'];
    //   this.user.name = params['name'];
    //  }
    // );

    // let id = +this.route.snapshot.params['id'];
    // console.log(id, 'id');

    // stateUniversityArray: Observable<any>;

    // getAll() {
    // return Observable.of(stateuniversityArray, 'array state university');
    // }

    // this.universitiesService.getAll() 
    //   .subscribe(data => {
    //     this.stateUniversityArray = data.universities;
    //     console.log(this.stateUniversityArray);
    //   });

  }

  ngOnDestroy(){
    //this.paramsSubscription.unsubscribe();

  
  }

   onLoadAxe(id: number){
    this.router.navigate(['/main-university', id, 'Axe'], {queryParams: {allowAxe: 'AxeDetails'}, fragment:'loading'});
  }



  getUniversityData(){
    this.universitiesService.getUniversityRequest().subscribe(
      universitiesData => {
          this.universitiesData = universitiesData;
          console.log(this.universitiesData , 'unicount');
          this.universityData = this.universitiesData.data.universities;
          console.log(this.universityData , 'university data'); 
          this.name = this.universityData.basicInfo.name;
          console.log(this.name , 'university name');
          // this.mainUniversityData = this.universityData.id;
          // console.log(this.mainUniversityData , 'main university data');
      },
      (error) => console.log(error)
    );
  }
  

 

  categoryLinkLists: CategoryLinkLists[] = [
  new CategoryLinkLists('info'),
  new CategoryLinkLists('course & fee'),
  new CategoryLinkLists('admissions'),
  new CategoryLinkLists('placements'),
  new CategoryLinkLists('scholarship'),
  new CategoryLinkLists('faculty'),
  new CategoryLinkLists('reviews')];

  mainUniversity: MainUniversity[] = [
    new MainUniversity('sri krishnadevaraya university', 'anantapur, andhra pradesh', 'assets/images/universities/states/andhrapradesh/sku.webp','assets/images/universities/states/andhrapradesh/mainBg/sku_ap.webp')
    
  ];

}
